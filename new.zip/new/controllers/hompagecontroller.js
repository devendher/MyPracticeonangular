app.controller('homepagecontroller',function($scope,$http,$window,$location,$cookieStore,$modal,$log,$rootScope,$timeout)
{
	
})