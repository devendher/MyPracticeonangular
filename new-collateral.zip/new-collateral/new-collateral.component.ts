import { Component, OnInit } from '@angular/core';
import {CollateralService} from '../collateral.service';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { CollateralReponse } from '../collateralData';

@Component({
  selector: 'new-collateral',
  templateUrl: './new-collateral.component.html',
  styleUrls: ['./new-collateral.component.scss']
})
export class NewCollateralComponent implements OnInit {
 public selectedTabValue: string;
     public newCollateralForm:FormGroup;
  constructor(private collateralService:CollateralService) { }

  ngOnInit() {
     this.selectedTabValue = 'Collateral Details';
     this.newCollateralForm=this.collateralService.getCollateralForm();
      this.collateralService.setupAutoSave(this.newCollateralForm, {
                  next: (value) => console.log(value),
                  error: (value) => console.log(value),
                  complete: () => { }
            });
     //console.log('new colleteral',this.newCollateralForm.controls.details);
  }
  public tabSelection(valueFromTab: string) {
        this.selectedTabValue = valueFromTab;
        console.log("From Collateral", this.selectedTabValue);

    }
}
