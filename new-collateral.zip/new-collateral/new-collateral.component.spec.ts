import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewCollateralComponent } from './new-collateral.component';

describe('NewCollateralComponent', () => {
  let component: NewCollateralComponent;
  let fixture: ComponentFixture<NewCollateralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewCollateralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewCollateralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
