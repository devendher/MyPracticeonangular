import { Component, OnInit, Input, SimpleChanges, OnChanges, Output, EventEmitter,ChangeDetectorRef,ChangeDetectionStrategy } from "@angular/core";
import { environment } from "../../../environments/environment";
import { GridDataResult, DataStateChangeEvent } from "@progress/kendo-angular-grid";
import { process, State } from "@progress/kendo-data-query";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Http } from "@angular/http";
import "rxjs/add/operator/map";
import "rxjs/add/operator/toPromise";
import "rxjs/Rx";
import { isUndefined } from "util";
import { DocumentService } from './document.service';
import { DocRefValues } from './document_data';
import { DocumentItemModel } from './document-model';
@Component({
  selector: 'collateral-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.scss'],
  providers: [DocumentService]
})
export class DocumentComponent implements OnInit {

  public gridData: any[];
  successMsg: boolean = false;
  errMsg: boolean = false;
  errorMessage: string;
  showLoader: boolean = false;
  public events: any[] = [];
  public saveData: boolean = true;
  public updateData: boolean = false;
  numberOfTicks:number=0;
  public dialogTitleName: string = 'Add Document Details';
  public rowIndex: number;
  //TODO property services to get this
  private state: State = {
    skip: 0,
    take: 10
  };
  //TODO get it from Service If we have any API for Document status

  public documentStatus: Array<string> = ["Status1", "Status2", "Status3"];

  private gridView: GridDataResult;
  //?
  public addDocumentForm: FormGroup;
  public showPopupDialog: boolean = false;

  divForNormalGrid: boolean = true;
  divForSummaryGrid: boolean = false;

  url = "./document_data.json";
  @Input()
  showAddDocumentBtn: boolean = true;
  @Input()
  showSummaryGrid: boolean = false;



  //?TOTO for services on the URL and should not pass url from here
  constructor(private _fb: FormBuilder, private documentService: DocumentService,private cd:ChangeDetectorRef) {
setInterval(()=>{
  this.numberOfTicks++;
  this.cd.markForCheck();
},1000)
  }

  ngOnInit() {
    this.customizeChargeGridForSummaryComp();
    this.documentService.getData([]).subscribe(
      response => {
        console.log(response)
      },
      error => {
        this.showLoader = false;
        this.successMsg = false;
        this.gridData = DocRefValues;
        this.gridView = process(this.gridData, this.state);
      },
      () => {
        console.log("Completed");
      }
    );
    console.log(this.gridData);
  

    this.addDocumentForm = this._fb.group({
      documentCode: ['', [<any>Validators.required, <any>Validators.required]],
      documentStatus: ['', [<any>Validators.required, <any>Validators.required]],
      dueDate: ['', [<any>Validators.required, <any>Validators.required]],
      documentReceivedDate: ['', [<any>Validators.required, <any>Validators.required]],
      documentExpirationDate: ['', [<any>Validators.required, <any>Validators.required]],
      documentDate: ['', [<any>Validators.required, <any>Validators.required]],
      document_expiry_date: ['', [<any>Validators.required, <any>Validators.required]],
      comments: []
    });
    this.subscribeToFormChanges();

  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes['gridData']) {
      console.log("data has been changed");
    }
  }
  addDocument() {
    this.dialogTitleName = 'Add Document Details';
    this.showPopupDialog = true;
  }
  protected dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridView = process(this.gridData, this.state);
  }
  subscribeToFormChanges() {
    const addDocumentFormStatusChanges$ = this.addDocumentForm.statusChanges;
    const addDocumentFormValueChanges$ = this.addDocumentForm.valueChanges;
    addDocumentFormStatusChanges$.subscribe(x => this.events.push({ event: 'STATUS_CHANGED', object: x }));
    addDocumentFormValueChanges$.subscribe(x => this.events.push({ event: 'VALUE_CHANGED', object: x }));
    addDocumentFormValueChanges$.subscribe(x => this.events.push({ event: 'VALUE_CHANGED', object: x }));
  }
  closeEventFromPopupDialog(showPopupDialog: boolean) {
    this.showPopupDialog = showPopupDialog;
    this.updateData = false;
    this.saveData = true;
    this.addDocumentForm.reset();
  }
  //TODO :-Add document details on click of Save button through popupDialog box once we get API
  addDocumentData(data: any) {
    this.gridData = [];
    console.log(data);
    this.addDocumentForm.reset();
    this.showPopupDialog = false;
    DocRefValues.push(data);
    this.gridData = DocRefValues;
    this.cd.detectChanges();
    this.gridView = process(this.gridData, this.state);
  }
  cancelForm() {
    this.showPopupDialog = false;
    this.addDocumentForm.reset();
  }
  updateDocument(data: DocumentItemModel) {
    console.log(data['documentCode']);
    this.saveData = true;
    this.updateData = false;
    this.showPopupDialog = false;
    console.log(this.gridData);
    console.log(this.rowIndex);
    this.gridData[this.rowIndex] = data;
    this.gridView = process(this.gridData, this.state);
    console.log(data);
    this.addDocumentForm.reset();
  }
  public editFunc(item: DocumentItemModel, index: number): void {
    this.dialogTitleName = 'Update Document';
    console.log("row index" + index);
    this.rowIndex = index;
    console.log(item['documentCode']);
    this.saveData = false;
    this.updateData = true;
    this.showPopupDialog = true;
    if (item != undefined) {
      this.addDocumentForm = this._fb.group(item);
      this.subscribeToFormChanges();
    }
  }
  public removeItemFunc(itemIndex: number) {
    this.gridData.splice(itemIndex, 1);
    this.gridView = process(this.gridData, this.state);
  }
  customizeChargeGridForSummaryComp() {
    if (this.showSummaryGrid) {
      this.divForNormalGrid = false;
      this.divForSummaryGrid = true;
    } else {
      this.divForNormalGrid = true;
      this.divForSummaryGrid = false;
    }
  }
   
}
