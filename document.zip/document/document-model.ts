export class DocumentItemModel {
    documentCode: string;
    documentStatus: string;
    documentDate: Date;
    dueDate: Date;
    documentReceivedDate: Date;
    documentExpirationDate: Date;
    comments: string;
    // delete: false;
    // id:string;
}