import { TestBed, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from "@angular/http/testing";
import { fakeAsync } from "@angular/core/testing";
import { BaseRequestOptions, Http, HttpModule, RequestMethod, Response, ResponseOptions } from "@angular/http";


import { DocumentService } from './document.service';
import { DocRefValues } from './document_data';

fdescribe('DocumentService', () => {
  let documentService: DocumentService;
  let mockBackend: MockBackend;
  //TODO API URL will be taken from environment file
  let tempUrl = './document_date.json';
  //let upadteURL =;
  let data = DocRefValues;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backend: MockBackend, options: BaseRequestOptions) => {
            return new Http(backend, options);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        DocumentService
      ],
      imports: [HttpModule]
    });
  });

  beforeEach(
    inject([DocumentService, MockBackend], (service: DocumentService, backend: MockBackend) => {
      documentService = service;
      mockBackend = backend;
    })
  );

  it('should ...', inject([DocumentService], (service: DocumentService) => {
    expect(service).toBeTruthy();
    console.log("Srevice:Documentaservice.... PASSED");
  }));
  it('service should be defined', () => {
    expect(DocumentService).toBeDefined();
    console.log('Service : DocumentService -- service should be defined -- PASSED')
  });
  it('Document Grid - should get response from mock server ', fakeAsync(() => {
    let mockResponseBody = DocRefValues;
    mockBackend.connections.subscribe((connection: MockConnection) => {
      let response = new ResponseOptions({ body: JSON.stringify(mockResponseBody) });
      connection.mockRespond(new Response(response));
    });
    documentService.getData([]).subscribe((response: Response) => {
      console.log('Service : DocumentService -- Document GRID- should response mock server -- PASSED')
    });

  }));

});
