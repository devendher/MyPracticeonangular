import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DocumentComponent } from './document.component';
import { AutoCompleteModule } from "@progress/kendo-angular-dropdowns";
import { PopupDialogModule } from '../../common/popup-dialog/popup-dialog.module';
import { CommonUIModule } from '../../common/commonUI.module';
import { LoaderModule } from "../../shared/progression/loader/loader.module";
import { CounterpartyDetailsModule } from "../../shared/counterparty-details/counterparty-details.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { CommonModule } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ClsSharedCommonModule } from "../../shared/";
import { DocRefValues } from './document_data';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from "@angular/core";
import { By } from "@angular/platform-browser";


fdescribe('DocumentComponent test cases', () => {
  let component: DocumentComponent;
  let fixture: ComponentFixture<DocumentComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CounterpartyDetailsModule,
        AutoCompleteModule,
        LoaderModule,
        CommonModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        ButtonsModule,
        BrowserAnimationsModule,
        GridModule,
        ClsSharedCommonModule,
        PopupDialogModule,
        CommonUIModule
      ],
      declarations: [DocumentComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('PopDialog should be disabled',
    async(() => {
      expect(component.showPopupDialog).toBe(false);
      console.log('Component : DocumentComponent -- PopDialob should be disabled -- PASSED');
    }));

  it('PopDialog box should open onclick of ADD DOCUMENT button',
    async(() => {
      fixture.detectChanges();
      component.showPopupDialog = false;
      component.addDocument();
      expect(component.showPopupDialog).toBe(true);
      console.log('Component : DocumentComponent --PopDialog box should open onclick of ADD DOCUMENT button -- PASSED');
    }));
  it('PopDialog box should be close  onclick of Cancel button',
    async(() => {
      fixture.detectChanges();
      component.showPopupDialog = true;
      component.cancelForm();
      expect(component.showPopupDialog).toBe(false);
      console.log('Component : DocumentComponent --PopDialog box should be close  onclick of Cancel button -- PASSED');
    }));
  it('PopDialog box should be close  onclick of close  button',
    async(() => {
      fixture.detectChanges();
      component.showPopupDialog = true;
      component.closeEventFromPopupDialog(false);
      expect(component.showPopupDialog).toBe(false);
      console.log('Component : DocumentComponent --PopDialog box should be close  onclick of close  button -- PASSED');
    }));

  /*Grid unit test */

  it('should display 7 columns in kendo grid', () => {

    let de: DebugElement = fixture.debugElement.query(By.css('thead tr'));
    let el: HTMLElement = de.nativeElement;
    expect(el.childElementCount).toEqual(7);
    console.log("Component : DocumentComponent -- should contain 6 columns in kendo grid-- PASSED");
  });

  it('Data should display in grid when document loaded', async(() => {
    fixture.detectChanges();
    component.gridData = DocRefValues;
    expect(component.gridData).toBe(DocRefValues);
    console.log("Component : DocumentComponent -- Data should display in grid when document loaded -- PASSED");
  }));

  it('should display Header in kendo grid', () => {
    fixture.detectChanges();

    let de: DebugElement = fixture.debugElement.query(By.css('.k-header'));
    let el: HTMLElement = de.nativeElement;
    expect(el.textContent).toContain("Document");
    console.log("Component : DocumentComponent -- should contain Document in first column header in kendo grid-- PASSED");
  });

});
