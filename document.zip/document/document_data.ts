export const DocRefValues = [{
	"documentCode": "DOC1",
	"documentStatus":"Status1",
	"documentDate": "18 Apr 2017",
	"dueDate":"30 Apr 2017",
	"documentReceivedDate": "21 Apr 2017",
	"documentExpirationDate": "27 Apr 2017",
	"comments": "--"
},
{
	"documentCode": "DOC2",
	"documentStatus":"Status1",
	"documentDate": "18 Apr 2017",
	"dueDate":"30 Apr 2017",
	"documentReceivedDate": "21 Apr 2017",
	"documentExpirationDate": "27 Apr 2017",
	"comments": "--"
}
];