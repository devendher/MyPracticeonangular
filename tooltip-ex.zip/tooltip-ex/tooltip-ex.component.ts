import { Component, OnInit ,Input} from '@angular/core';

@Component({
  selector: 'app-tooltip-ex',
  templateUrl: './tooltip-ex.component.html',
  styleUrls: ['./tooltip-ex.component.css']
})
export class TooltipExComponent implements OnInit {

  constructor() { }
  @Input()
  title:string='';
  @Input()
  message:string='';


  ngOnInit() {
  }

}
